# ROS 2 Jazzy → Arduino → Single DC Motor (proof of concept)

## What this is

`cmd_vel_to_arduino.py` listens to Nav2 velocity requests and sends `M:100\n`
when either forward/backward or turning movement is requested; otherwise it
sends `M:0\n`. The Arduino sketch drives a **single brushed DC motor** through
an appropriately rated PWM/direction H-bridge. The onboard Arduino LED also lights while a motor command is active, so you can verify serial messages with the motor supply disconnected. This tests communications; it
**does not** steer the robot correctly or establish goal arrival. Nav2 needs
live /scan, /odom, localization, and an active controller to publish motion.

### Safety

- This sketch is only for drivers accepting PWM + IN1 + IN2 controls.
- Use an external motor power supply with suitable voltage/current limits; never power the motor from an Arduino GPIO pin.
- Share driver and Arduino signal ground. Follow your driver's actual documentation.
- Perform initial tests with the motor unloaded / wheels lifted, and provide a physical means to cut motor power.
- USB command loss stops the motor within roughly 0.7 seconds at the Arduino. The Python bridge independently stops requesting motion after 0.5 seconds without fresh velocity messages.
- Do not use this single-motor demo for unattended or mobile navigation.

## Steps

1. Connect the Arduino USB device to Ubuntu through VirtualBox (separate from the LiDAR USB device).
2. Upload `arduino_nav2_motor_test.ino` from Arduino IDE. Close the Arduino IDE Serial Monitor before running the bridge.
3. Confirm your motor-driver wiring is appropriate for *your specific hardware*.
4. Install bridge dependencies: `sudo apt install python3-serial`.
5. Find Arduino port: `ls -l /dev/serial/by-id/` or `ls /dev/ttyACM* /dev/ttyUSB* 2>/dev/null`.
6. Start navigation: `ros2 launch robot_mapping navigation.launch.py rviz:=true` and give the robot its initial pose in RViz.
7. Check the velocity topic type: `ros2 topic info /cmd_vel` and its publishers with `ros2 topic info /cmd_vel -v`.
8. Run:
   ```bash
   source /opt/ros/jazzy/setup.bash
   source ~/ros2_ws/install/setup.bash
   python3 cmd_vel_to_arduino.py --port /dev/ttyACM0
   ```
   Replace the port with your actual Arduino port. For TwistStamped, add `--stamped`. If your final commanded output is on a different topic, supply `--topic /your_topic`.
9. With Nav2 not issuing commands, test the chain using:
   ```bash
   ros2 topic pub -r 5 /cmd_vel geometry_msgs/msg/Twist '{linear: {x: 0.10}}'
   ```
   Stop with Ctrl+C; the Arduino motor should stop automatically.
10. Select a **Nav2 Goal** with the navigation server active. This is different from setting a `/goal_pose` for the manual waypoint monitor. The single test motor will run **only when Nav2 actually publishes nonzero velocity**. With no driven wheels Nav2 can time out because the robot never moves. This is expected.

## Debugging

- `ros2 topic list -t | grep cmd_vel`
- `ros2 topic info /cmd_vel -v`
- `ros2 topic echo /cmd_vel`
- `ros2 action list | grep navigate`
- `ls -l /dev/serial/by-id/`
- `groups` (ensure `dialout`; re-login if needed)

If your motor is a REV/brushless device or your driver lacks separate PWM/IN1/IN2 pins, **do not wire it as shown**. We must adapt the Arduino sketch to that controller's interface.
