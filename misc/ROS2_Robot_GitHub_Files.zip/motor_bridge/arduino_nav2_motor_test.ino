/*
  ROS 2 /cmd_vel -> serial -> ONE BRUSHED DC MOTOR demonstration.

  For an Arduino Uno/Nano and H-bridge driver with PWM enable + 2 direction inputs
  (for example an appropriately rated L298N). This sketch is NOT for a REV SPARK,
  brushless controller, servo, stepper, or a driver with a different interface.

  Connections (example only):
    Arduino D5 (PWM) -> H-bridge ENA/PWM  (remove ENA jumper on L298N)
    Arduino D7       -> H-bridge IN1
    Arduino D8       -> H-bridge IN2
    Arduino GND      -> H-bridge GND
    Motor            -> H-bridge motor output A
    Motor power      -> EXTERNAL, properly rated supply via H-bridge

  NEVER power a DC motor directly from an Arduino output pin.
  Test with the wheel lifted/disconnected from the drivetrain.
*/

const byte PWM_PIN = 5;
const byte IN1_PIN = 7;
const byte IN2_PIN = 8;
const int MAX_TEST_PWM = 110;
const unsigned long TIMEOUT_MS = 700;

char buffer[20];
byte bufferLength = 0;
unsigned long lastValidCommand = 0;
int lastPwm = -1;

void motorWrite(int pwm) {
  pwm = constrain(pwm, 0, MAX_TEST_PWM);
  digitalWrite(LED_BUILTIN, pwm > 0 ? HIGH : LOW);
  if (pwm == 0) {
    analogWrite(PWM_PIN, 0);
    digitalWrite(IN1_PIN, LOW);
    digitalWrite(IN2_PIN, LOW);
  } else {
    digitalWrite(IN1_PIN, HIGH);
    digitalWrite(IN2_PIN, LOW);
    analogWrite(PWM_PIN, pwm);
  }
  if (pwm != lastPwm) {
    Serial.print("ACK PWM=");
    Serial.println(pwm);
    lastPwm = pwm;
  }
}

void processLine(const char *line) {
  if (strncmp(line, "M:", 2) != 0) return;
  char *end = nullptr;
  long pwm = strtol(line + 2, &end, 10);
  if (end == line + 2 || *end != '\0' || pwm < 0 || pwm > 255) return;
  lastValidCommand = millis();
  motorWrite((int)pwm);
}

void setup() {
  pinMode(LED_BUILTIN, OUTPUT);
  digitalWrite(LED_BUILTIN, LOW);
  pinMode(PWM_PIN, OUTPUT);
  pinMode(IN1_PIN, OUTPUT);
  pinMode(IN2_PIN, OUTPUT);
  digitalWrite(IN1_PIN, LOW);
  digitalWrite(IN2_PIN, LOW);
  analogWrite(PWM_PIN, 0);
  Serial.begin(115200);
  lastValidCommand = millis();
  Serial.println("READY");
}

void loop() {
  while (Serial.available() > 0) {
    char c = (char)Serial.read();
    if (c == '\n') {
      buffer[bufferLength] = '\0';
      processLine(buffer);
      bufferLength = 0;
    } else if (c != '\r') {
      if (bufferLength < sizeof(buffer) - 1) {
        buffer[bufferLength++] = c;
      } else {
        bufferLength = 0;  // discard overlong/corrupted command
        motorWrite(0);
      }
    }
  }
  if (millis() - lastValidCommand > TIMEOUT_MS) {
    motorWrite(0);
  }
}
