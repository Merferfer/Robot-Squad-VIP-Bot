#!/usr/bin/env python3
"""ROS 2 Jazzy /cmd_vel -> USB serial -> Arduino motor demonstration.

Proof-of-concept only: ONE motor spins whenever Nav2 requests motion. It
is NOT a differential-drive controller and does not translate Twist into
physically correct left/right wheel velocities.
"""

import argparse
import time

import rclpy
from rclpy.node import Node
from rclpy.executors import ExternalShutdownException
from geometry_msgs.msg import Twist, TwistStamped
import serial

BAUD_RATE = 115200
MOTOR_TEST_PWM = 100          # Arduino PWM range: 0..255; start conservatively
COMMAND_TIMEOUT_S = 0.50    # stop sending motor-on if Nav2 goes quiet
TRANSMIT_PERIOD_S = 0.10    # 10 Hz; Arduino independently times out as well


class CmdVelArduinoBridge(Node):
    def __init__(self, port: str, topic: str, stamped: bool):
        super().__init__('cmd_vel_arduino_bridge')
        self.arduino = serial.Serial(
            port=port, baudrate=BAUD_RATE, timeout=0,
            write_timeout=0.25,
        )
        # Many Arduino boards reset when their serial port is opened.
        time.sleep(2.0)
        self.last_velocity_time = None
        self.want_motor_on = False
        self.last_motor_on = None
        msg_type = TwistStamped if stamped else Twist
        self.sub = self.create_subscription(msg_type, topic, self.on_velocity, 10)
        self.timer = self.create_timer(TRANSMIT_PERIOD_S, self.send_command)
        self.get_logger().info(
            f'Listening: {topic} ({msg_type.__name__}); Arduino: {port} @ {BAUD_RATE}'
        )
        self.get_logger().info('MOTOR OFF until fresh nonzero velocity commands arrive.')

    def on_velocity(self, message):
        twist = message.twist if isinstance(message, TwistStamped) else message
        self.want_motor_on = (
            abs(twist.linear.x) > 0.02 or abs(twist.angular.z) > 0.05
        )
        self.last_velocity_time = time.monotonic()

    def send_command(self):
        fresh = (self.last_velocity_time is not None and
                 time.monotonic() - self.last_velocity_time < COMMAND_TIMEOUT_S)
        motor_on = fresh and self.want_motor_on
        pwm = MOTOR_TEST_PWM if motor_on else 0
        try:
            self.arduino.write(f'M:{pwm}\n'.encode('ascii'))
            # Arduino sends READY and status updates, if available.
            for _ in range(5):
                if not self.arduino.in_waiting:
                    break
                message = self.arduino.readline().decode('ascii', errors='replace').strip()
                if message:
                    self.get_logger().info(f'Arduino: {message}')
        except (serial.SerialException, serial.SerialTimeoutException, OSError) as exc:
            self.get_logger().error(f'USB serial failure: {exc}; bridge will stop.')
            rclpy.shutdown()
            return
        if motor_on != self.last_motor_on:
            self.get_logger().info(
                f'MOTOR {"ON" if motor_on else "OFF"} | PWM={pwm}'
            )
            self.last_motor_on = motor_on

    def close(self):
        try:
            if self.arduino.is_open:
                self.arduino.write(b'M:0\n')
                self.arduino.flush()
                self.arduino.close()
        except (serial.SerialException, serial.SerialTimeoutException, OSError):
            pass  # Arduino has an independent timeout as a second safeguard.


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', required=True, help='Arduino serial port (not LiDAR)')
    parser.add_argument('--topic', default='/cmd_vel', help='Velocity-command ROS topic')
    parser.add_argument('--stamped', action='store_true',
                        help='Use geometry_msgs/TwistStamped instead of Twist')
    args = parser.parse_args()

    rclpy.init()
    node = None
    try:
        node = CmdVelArduinoBridge(args.port, args.topic, args.stamped)
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        if node is not None:
            node.close()
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
