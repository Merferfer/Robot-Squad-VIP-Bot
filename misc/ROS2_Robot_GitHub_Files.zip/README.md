# ROS 2 Jazzy / Slamtec C3 Robot — Team Handoff

This ZIP contains the project source files shared in our ChatGPT work. **It is not a complete clone of the working Ubuntu VM.** Use `collect_actual_workspace.sh` to collect the real workspace configuration and saved map; see `docs/MISSING_FROM_ARCHIVE.md`.

## What has been verified

- LiDAR `/scan` and RF2O `/odom` worked at approximately 10 Hz.
- SLAM Toolbox produced an occupancy map; it was saved and reused in navigation mode.
- AMCL localization produced `/amcl_pose` after a 2D Pose Estimate.
- `goal_monitor.py` was tested by manually moving the LiDAR to a goal and seeing waypoint arrival.
- `waypoint_route_monitor.py` has been provided but **was not confirmed tested**.
- ROS-to-Arduino communication was under LED testing. Physical motor driving and automatic waypoint navigation **have not been confirmed**.

## Included project files

| File | Purpose |
| --- | --- |
| `launch/mapping.launch.py` | Slamtec scan + RF2O + static laser TF + SLAM Toolbox |
| `launch/navigation.launch.py` | Corrected Jazzy launch for map + AMCL + Nav2 + sensors |
| `waypoints/goal_monitor.py` | Single goal: `/goal_pose` + `/amcl_pose`, terminal arrival |
| `waypoints/waypoint_route_monitor.py` | Manual route: `/clicked_point` + `/amcl_pose`, heading and distance, waypoint markers and route save/load |
| `motor_bridge/cmd_vel_to_arduino.py` | Serial demonstration from `/cmd_vel` to Arduino |
| `motor_bridge/arduino_nav2_motor_test.ino` | Single brushed DC motor demonstration for PWM/IN1/IN2 H-bridge |
| `motor_bridge/ARDUINO_TEST_README.md` | Motor demo setup and safety |
| `config_examples/rf2o_nav.example.yaml` | **Example**, not live RF2O settings |
| `docs/HEADINGS_AND_DIRECTIONS.md` | Angle math, left/right conventions, Nav2 motion |
| `docs/QUICKSTART_COMMANDS.md` | Mapping, overwrite/save, navigation, monitors |
| `docs/MISSING_FROM_ARCHIVE.md` | Files needed from original Ubuntu workspace |
| `collect_actual_workspace.sh` | Run on Ubuntu to create ZIP of actual configs/map |

## Basic flow

**Mapping mode** (stop navigation first):

```bash
cd ~/ros2_ws
source /opt/ros/jazzy/setup.bash
source install/setup.bash
ros2 launch robot_mapping mapping.launch.py rviz:=true
```

**Overwrite saved map** (keep mapping active):

```bash
ros2 run nav2_map_server map_saver_cli -f ~/ros2_ws/maps/my_map
```

**Navigation mode** (stop mapping first):

```bash
cd ~/ros2_ws
source /opt/ros/jazzy/setup.bash
source install/setup.bash
ros2 launch robot_mapping navigation.launch.py map:=$HOME/ros2_ws/maps/my_map.yaml rviz:=true
```

Use RViz2 **2D Pose Estimate** first. For the tested single-waypoint monitor, launch `python3 ~/ros2_ws/goal_monitor.py` and select a point with RViz2 **2D Goal Pose**. For the unverified route monitor, launch `python3 ~/ros2_ws/waypoint_route_monitor.py` and use RViz2 **Publish Point**.

## Important implementation boundaries

- The manual monitors provide **straight-line heading/distance and arrival**, not obstacle-avoiding path execution or motor commands.
- The Arduino bridge is an **on/off test motor** based on whether a command is nonzero; it does not compute actual left and right wheel velocities or steer.
- Do not put the robot on the ground for autonomous driving until actual dimensions, LiDAR mounting transform, motor controller interface, motion limits, encoder feedback, and an accessible emergency-stop mechanism are verified.
- The included launch files assume separate ROS package installation/metadata and local configuration YAMLs, which must be copied from your VM.
