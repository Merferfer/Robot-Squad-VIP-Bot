# Files still needed from your Ubuntu VM

The handoff ZIP contains available code from our conversation, **not the complete running system**. I cannot read your Ubuntu VirtualBox filesystem directly.

To make the team's copy fully reproducible, collect the live copies of:

- `~/ros2_ws/src/robot_mapping/slam.yaml` (SLAM Toolbox config)
- `~/ros2_ws/src/robot_mapping/config/nav2_params.yaml` (Nav2 config)
- `~/ros2_ws/maps/my_map.yaml` and `my_map.pgm` (the actual map)
- `~/ros2_ws/rf2o_nav.yaml` (if used)
- `~/ros2_ws/src/robot_mapping/package.xml` and its `setup.py`, `setup.cfg`, or `CMakeLists.txt` as applicable
- Any saved `~/ros2_ws/maps/manual_waypoints.json` (if you used save)
- Your actual hardware pin map, motor controller model, measured LiDAR mount offsets, wheel geometry, and any modifications made directly inside the VM.

The provided `config_examples/rf2o_nav.example.yaml` is a **reconstruction**, not the actual machine file.

Run `collect_actual_workspace.sh` inside Ubuntu to create a separate ZIP of files which exist there. Review the archive before sharing: the map may disclose your environment's floor plan. Use live file versions rather than assuming our earlier supplied versions are the same as your current edits.

Arduino IDE's 193 MB AppImage is not part of the project source archive.
