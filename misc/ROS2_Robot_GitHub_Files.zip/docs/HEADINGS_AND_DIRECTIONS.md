# Headings & Directions — Team Technical Reference

## 1. Coordinate frames

```text
map -> odom -> base_footprint -> laser
```

- In navigation mode, **AMCL** estimates `map -> odom`.
- In mapping mode, **SLAM Toolbox** provides `map -> odom`.
- **RF2O** publishes `odom -> base_footprint`.
- A *measured* static transform gives `base_footprint -> laser`.
- Standard ROS planar robot convention: X forward, Y left, Z up; positive yaw is a counterclockwise/left rotation.

The supplied launch files use zero LiDAR mounting offsets as placeholders. Change `laser_x`, `laser_y`, `laser_z`, and `laser_yaw` to match the robot's physical sensor mount if necessary.

## 2. Destination bearing and heading error

The `waypoint_route_monitor.py` program gets `(x_r,y_r)` and yaw from `/amcl_pose`, then uses a clicked goal `(x_g,y_g)` in the `map` frame.

```python
dx = x_g - x_r
dy = y_g - y_r
distance_m = math.hypot(dx, dy)
target_heading_rad = math.atan2(dy, dx)
heading_error_rad = math.atan2(
    math.sin(target_heading_rad - robot_yaw_rad),
    math.cos(target_heading_rad - robot_yaw_rad),
)
heading_error_deg = math.degrees(heading_error_rad)
```

Interpretation: **positive heading error means turn LEFT**; **negative means RIGHT**; absolute error <= 15 degrees prints `ahead`. Arrival is based on position within **0.30 m**; final orientation is not checked.

This heading points along the **straight line to the waypoint**. It does **not** calculate a safe path around obstacles, and errors increase if AMCL loses localization.

## 3. RViz input tool differences

| Tool | Topic/action | Use |
| --- | --- | --- |
| `2D Pose Estimate` | `/initialpose` | Initialize AMCL position |
| `2D Goal Pose` | `/goal_pose` | Manual `goal_monitor.py` input |
| `Publish Point` | `/clicked_point` | Queue points in `waypoint_route_monitor.py` |
| `Nav2 Goal` | Nav2 navigation action | Request real Nav2 navigation; requires active Nav2 servers |

The two manual monitors **do not** drive motors.

## 4. What Nav2 sends

For differential-drive-style movement, velocity commands normally carry:

- `linear.x` in m/s: forward (+) / reverse (-).
- `angular.z` in rad/s: left/CCW (+) / right/CW (-).

Example: `linear.x=0.10, angular.z=+0.50` requests forward motion while turning left. Verify whether your Nav2 output is `/cmd_vel`, `/cmd_vel_smoothed`, `Twist` or `TwistStamped` with `ros2 topic list -t | grep cmd_vel` and `ros2 topic info /cmd_vel -v`.

**Current `cmd_vel_to_arduino.py` does not preserve the heading or magnitude.** It sends `M:100` to turn ONE test motor on for nonzero commands and `M:0` otherwise. Actual steering is future work.

## 5. Future differential-drive conversion (NOT IMPLEMENTED)

If the robot has conventional left/right driven wheels of radius `r` and track width `b`, with `v=linear.x` and `w=angular.z`:

```text
v_left  = v - (b/2) * w
v_right = v + (b/2) * w
wheel_rad_s_left  = v_left / r
wheel_rad_s_right = v_right / r
```

A positive `w` makes the right side faster and turns the robot left. This equation is NOT valid for arbitrary mecanum, steering, or swerve drives. To make real movement safe and accurate, implement the correct motor-driver protocol, proper geometric calibration, command saturation, acceleration limits, encoder feedback, and hardware emergency stop. The included Arduino example assumes a simple brushed DC H-bridge; it is **not a REV motor controller sketch**.

## 6. Debugging

```bash
ros2 topic hz /scan
ros2 topic hz /odom
ros2 topic echo /amcl_pose --once
ros2 run tf2_ros tf2_echo map base_footprint
ros2 run tf2_ros tf2_echo odom base_footprint
ros2 topic info /cmd_vel -v
ros2 action list
```
