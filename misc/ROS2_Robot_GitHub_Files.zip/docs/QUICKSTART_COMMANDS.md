# Startup & Save Commands

## Mapping
```bash
cd ~/ros2_ws
source /opt/ros/jazzy/setup.bash
source install/setup.bash
ros2 launch robot_mapping mapping.launch.py rviz:=true
```

## Overwrite existing saved map (while mapping is RUNNING)
```bash
source /opt/ros/jazzy/setup.bash
source ~/ros2_ws/install/setup.bash
mkdir -p ~/ros2_ws/maps
ros2 run nav2_map_server map_saver_cli -f ~/ros2_ws/maps/my_map
ls -lh ~/ros2_ws/maps/my_map*
```

## Navigation (stop mapping FIRST)
```bash
cd ~/ros2_ws
source /opt/ros/jazzy/setup.bash
source install/setup.bash
ros2 launch robot_mapping navigation.launch.py map:=$HOME/ros2_ws/maps/my_map.yaml rviz:=true
```
In RViz, set **2D Pose Estimate** on the saved map.

## Single waypoint monitoring (tested by manually moving LiDAR)
```bash
python3 ~/ros2_ws/goal_monitor.py
```
Use RViz **2D Goal Pose** (topic `/goal_pose`).

## Multi-waypoint tracking (not yet verified)
```bash
python3 ~/ros2_ws/waypoint_route_monitor.py
```
Use RViz **Publish Point** (topic `/clicked_point`). To save/load/clear route:
```bash
ros2 service call /manual_route_monitor/save std_srvs/srv/Trigger '{}'
ros2 service call /manual_route_monitor/load std_srvs/srv/Trigger '{}'
ros2 service call /manual_route_monitor/clear std_srvs/srv/Trigger '{}'
```
For RViz markers, add MarkerArray display `/manual_waypoint_markers`.

## Arduino serial bridge (one-motor test only)
```bash
sudo apt install python3-serial
ls -l /dev/serial/by-id/
python3 ~/ros2_ws/cmd_vel_to_arduino.py --port /dev/ttyACM0
```
Replace Arduino port. Upload the matching Arduino sketch first and close the Serial Monitor. To test only with Nav2 velocity publisher stopped:
```bash
ros2 topic pub -r 5 /cmd_vel geometry_msgs/msg/Twist '{linear: {x: 0.10}, angular: {z: 0.0}}'
```
Use Ctrl+C to stop. Verify Arduino's watchdog stops the motor; initial tests should be unloaded or with motor power disconnected.
