#!/usr/bin/env python3
"""Navigate an existing 2D map using a Slamtec C3, RF2O, and Nav2 on ROS 2 Jazzy.

This is a SEPARATE mode from mapping.launch.py: DO NOT run both simultaneously.

Prerequisites:
- ~/ros2_ws/maps/my_map.yaml (or map:=/path/to/map.yaml)
- ~/ros2_ws/src/robot_mapping/config/nav2_params.yaml
  Create it from /opt/ros/jazzy/share/nav2_bringup/params/nav2_params.yaml
  and change all robot_base_frame: base_link settings to base_footprint.
- Measure the robot's actual size; adjust robot_radius or footprint in the YAML
  before attempting physical autonomous driving.
- Check laser_x, laser_y, laser_z, laser_yaw against the actual LiDAR mount.
- A compatible /cmd_vel -> motor controller interface is required to move.
"""

from pathlib import Path
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    workspace = Path.home() / 'ros2_ws'
    nav2_launch = os.path.join(
        get_package_share_directory('nav2_bringup'), 'launch', 'bringup_launch.py'
    )
    rviz_cfg = os.path.join(
        get_package_share_directory('nav2_bringup'), 'rviz', 'nav2_default_view.rviz'
    )

    return LaunchDescription([
        DeclareLaunchArgument('serial_port', default_value='/dev/ttyUSB0'),
        DeclareLaunchArgument('map', default_value=str(workspace / 'maps' / 'my_map.yaml')),
        DeclareLaunchArgument('params_file', default_value=str(
            workspace / 'src' / 'robot_mapping' / 'config' / 'nav2_params.yaml'
        )),
        DeclareLaunchArgument('rviz', default_value='false'),
        # Use your *measured* LiDAR mounting offsets, not the defaults below,
        # unless the laser is truly located at the base_footprint origin.
        DeclareLaunchArgument('laser_x', default_value='0.0'),
        DeclareLaunchArgument('laser_y', default_value='0.0'),
        DeclareLaunchArgument('laser_z', default_value='0.0'),
        DeclareLaunchArgument('laser_yaw', default_value='0.0'),

        Node(
            package='sllidar_ros2', executable='sllidar_node',
            name='sllidar_node', output='screen',
            parameters=[{
                'channel_type': 'serial',
                'serial_port': LaunchConfiguration('serial_port'),
                'serial_baudrate': 460800,
                'frame_id': 'laser',
                'inverted': False,
                'angle_compensate': True,
                'scan_mode': 'Standard',
            }],
        ),

        Node(
            package='tf2_ros', executable='static_transform_publisher',
            name='laser_static_tf', output='screen',
            arguments=[
                '--x', LaunchConfiguration('laser_x'),
                '--y', LaunchConfiguration('laser_y'),
                '--z', LaunchConfiguration('laser_z'),
                '--roll', '0.0', '--pitch', '0.0',
                '--yaw', LaunchConfiguration('laser_yaw'),
                '--frame-id', 'base_footprint', '--child-frame-id', 'laser',
            ],
        ),

        Node(
            package='rf2o_laser_odometry',
            executable='rf2o_laser_odometry_node',
            name='CLaserOdometry2DNode', output='screen',
            parameters=[{
                'laser_scan_topic': '/scan',
                'odom_topic': '/odom',
                'odom_frame_id': 'odom',
                'base_frame_id': 'base_footprint',
                'publish_tf': True,
                'init_pose_from_topic': '',
                'freq': 10.0,
            }],
        ),

        # In navigation mode: map server + AMCL + planner/controller/waypoints.
        # No SLAM Toolbox; only AMCL should own map->odom.
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(nav2_launch),
            launch_arguments={
                'map': LaunchConfiguration('map'),
                'params_file': LaunchConfiguration('params_file'),
                'slam': 'False',
                'use_sim_time': 'false',
                'autostart': 'true',
                'use_composition': 'False',
            }.items(),
        ),

        Node(
            package='rviz2', executable='rviz2', name='rviz2',
            arguments=['-d', rviz_cfg], output='screen',
            condition=IfCondition(LaunchConfiguration('rviz')),
        ),
    ])
