#!/usr/bin/env python3
"""ROS 2 Jazzy mapping launch for Slamtec C3 (using tested C1 settings).

Starts Slamtec scans, RF2O odometry, base-to-laser static TF,
and asynchronous SLAM Toolbox. RViz can be enabled with rviz:=true.

Before using, check that the laser mounting offset is correct. The default
zero-offset static transform is appropriate only when the LiDAR frame's
origin is at the robot base frame's origin.
"""

import os
from pathlib import Path

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    slam_config = str(Path.home() / 'ros2_ws' / 'src' / 'robot_mapping' / 'slam.yaml')
    slam_launch = os.path.join(
        get_package_share_directory('slam_toolbox'),
        'launch',
        'online_async_launch.py',
    )

    return LaunchDescription([
        DeclareLaunchArgument('serial_port', default_value='/dev/ttyUSB0'),
        DeclareLaunchArgument('rviz', default_value='false'),
        # Set these values to the measured laser mount offset relative to base_footprint.
        DeclareLaunchArgument('laser_x', default_value='0.0'),
        DeclareLaunchArgument('laser_y', default_value='0.0'),
        DeclareLaunchArgument('laser_z', default_value='0.0'),
        DeclareLaunchArgument('laser_yaw', default_value='0.0'),

        # Slamtec C3: reuse the C1-compatible settings that worked previously.
        Node(
            package='sllidar_ros2',
            executable='sllidar_node',
            name='sllidar_node',
            output='screen',
            parameters=[{
                'channel_type': 'serial',
                'serial_port': LaunchConfiguration('serial_port'),
                'serial_baudrate': 460800,
                'frame_id': 'laser',
                'inverted': False,
                'angle_compensate': True,
                'scan_mode': 'Standard',
            }],
        ),

        # Defines where the LiDAR sits relative to the robot base.
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='laser_static_tf',
            output='screen',
            arguments=[
                '--x', LaunchConfiguration('laser_x'),
                '--y', LaunchConfiguration('laser_y'),
                '--z', LaunchConfiguration('laser_z'),
                '--roll', '0.0',
                '--pitch', '0.0',
                '--yaw', LaunchConfiguration('laser_yaw'),
                '--frame-id', 'base_footprint',
                '--child-frame-id', 'laser',
            ],
        ),

        # RF2O must broadcast odom -> base_footprint as well as publish /odom.
        Node(
            package='rf2o_laser_odometry',
            executable='rf2o_laser_odometry_node',
            name='CLaserOdometry2DNode',
            output='screen',
            parameters=[{
                'laser_scan_topic': '/scan',
                'odom_topic': '/odom',
                'odom_frame_id': 'odom',
                'base_frame_id': 'base_footprint',
                'publish_tf': True,
                # Empty string initializes RF2O at (0, 0). "none" does not.
                'init_pose_from_topic': '',
                'freq': 10.0,
            }],
        ),

        # Use SLAM Toolbox's lifecycle-aware launch file, keeping your slam.yaml.
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(slam_launch),
            launch_arguments={
                'slam_params_file': slam_config,
                'use_sim_time': 'false',
                'autostart': 'true',
            }.items(),
        ),

        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            output='screen',
            condition=IfCondition(LaunchConfiguration('rviz')),
        ),
    ])
