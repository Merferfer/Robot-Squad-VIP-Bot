#!/usr/bin/env bash
# Run within the actual Ubuntu 24.04 VM. Copy (never modify) relevant live project files.
set -euo pipefail
WS="$HOME/ros2_ws"
OUTPUT="$HOME/ros2_actual_workspace_$(date +%Y%m%d_%H%M%S).zip"
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
mkdir -p "$TEMP/ros2_ws"
copy_file(){
  local relative="$1"
  if [ -f "$WS/$relative" ]; then
    mkdir -p "$TEMP/ros2_ws/$(dirname "$relative")"
    cp -- "$WS/$relative" "$TEMP/ros2_ws/$relative"
    echo "Included $relative"
  else
    echo "Skipped (not found): $relative"
  fi
}
for path in \
  src/robot_mapping/launch/mapping.launch.py \
  src/robot_mapping/launch/navigation.launch.py \
  src/robot_mapping/slam.yaml \
  src/robot_mapping/config/slam.yaml \
  src/robot_mapping/config/nav2_params.yaml \
  src/robot_mapping/package.xml \
  src/robot_mapping/setup.py \
  src/robot_mapping/setup.cfg \
  src/robot_mapping/CMakeLists.txt \
  maps/my_map.yaml maps/my_map.pgm maps/manual_waypoints.json \
  rf2o_nav.yaml goal_monitor.py waypoint_route_monitor.py cmd_vel_to_arduino.py
  do copy_file "$path"
done
if ! command -v zip >/dev/null 2>&1; then
  echo 'Please install zip: sudo apt install zip' >&2
  exit 1
fi
(cd "$TEMP" && zip -qr "$OUTPUT" .)
echo "Created $OUTPUT"
echo 'Review this archive before sharing (saved maps reveal layouts).'
