#!/usr/bin/env python3
"""Manual multi-waypoint monitor for ROS 2 Jazzy.

Click goals using RViz's "Publish Point" tool (topic: /clicked_point).
Push the robot by hand; AMCL provides its current position on /amcl_pose.
This node DOES NOT command motors or call Nav2 navigation actions.

Services:
  /manual_route_monitor/save  - save waypoints to JSON
  /manual_route_monitor/load  - load saved waypoints (restart at waypoint 1)
  /manual_route_monitor/clear - discard the active route
"""

import json
import math
import os
import time
from pathlib import Path

import rclpy
from geometry_msgs.msg import PointStamped, PoseWithCovarianceStamped
from rclpy.node import Node
from std_srvs.srv import Trigger
from visualization_msgs.msg import Marker, MarkerArray


DEFAULT_ROUTE_PATH = Path.home() / 'ros2_ws' / 'maps' / 'manual_waypoints.json'


def wrap_angle(angle):
    return math.atan2(math.sin(angle), math.cos(angle))


class ManualRouteMonitor(Node):
    def __init__(self):
        super().__init__('manual_route_monitor')

        self.declare_parameter('tolerance_m', 0.30)
        self.declare_parameter('stale_after_sec', 3.0)
        self.declare_parameter('route_file', str(DEFAULT_ROUTE_PATH))

        self.tolerance_m = float(self.get_parameter('tolerance_m').value)
        self.stale_after_sec = float(self.get_parameter('stale_after_sec').value)
        self.route_file = Path(str(self.get_parameter('route_file').value)).expanduser()

        self.waypoints = []  # Ordered list of (x, y) in the map frame
        self.active_index = 0
        self.position = None
        self.yaw = None
        self.last_pose_time = None

        self.create_subscription(
            PoseWithCovarianceStamped, '/amcl_pose', self.on_pose, 10
        )
        self.create_subscription(
            PointStamped, '/clicked_point', self.on_clicked_point, 10
        )
        # Durable markers remain visible when a MarkerArray display is added in RViz.
        from rclpy.qos import QoSProfile, DurabilityPolicy, ReliabilityPolicy
        qos = QoSProfile(depth=1)
        qos.durability = DurabilityPolicy.TRANSIENT_LOCAL
        qos.reliability = ReliabilityPolicy.RELIABLE
        self.marker_pub = self.create_publisher(
            MarkerArray, '/manual_waypoint_markers', qos
        )

        self.create_service(Trigger, '~/save', self.save_route)
        self.create_service(Trigger, '~/load', self.load_route)
        self.create_service(Trigger, '~/clear', self.clear_route)
        self.create_timer(1.0, self.report_progress)

        self.get_logger().info(
            'Ready! In RViz, use Publish Point on /clicked_point to add waypoints in order.'
        )
        self.get_logger().info(
            f'Arrival tolerance: {self.tolerance_m:.2f} m. No motor commands will be sent.'
        )

    def on_pose(self, msg):
        if msg.header.frame_id.lstrip('/') != 'map':
            self.get_logger().warn('AMCL pose is not in map frame; ignoring it.')
            return
        p = msg.pose.pose.position
        q = msg.pose.pose.orientation
        self.position = (p.x, p.y)
        self.yaw = math.atan2(
            2.0 * (q.w * q.z + q.x * q.y),
            1.0 - 2.0 * (q.y * q.y + q.z * q.z),
        )
        self.last_pose_time = time.monotonic()

    def on_clicked_point(self, msg):
        if msg.header.frame_id.lstrip('/') != 'map':
            self.get_logger().warn(
                'Select the map fixed frame in RViz before placing waypoints.'
            )
            return
        self.waypoints.append((msg.point.x, msg.point.y))
        self.get_logger().info(
            f'ADDED waypoint {len(self.waypoints)}: '
            f'x={msg.point.x:.2f}, y={msg.point.y:.2f}'
        )
        self.publish_markers()

    def report_progress(self):
        if not self.waypoints or self.active_index >= len(self.waypoints):
            return
        if self.position is None or self.last_pose_time is None:
            self.get_logger().warn('Waiting for AMCL localization (/amcl_pose).')
            return
        if time.monotonic() - self.last_pose_time > self.stale_after_sec:
            self.get_logger().warn('AMCL data is stale; not checking for arrival.')
            return

        goal_x, goal_y = self.waypoints[self.active_index]
        dx = goal_x - self.position[0]
        dy = goal_y - self.position[1]
        distance = math.hypot(dx, dy)
        number = self.active_index + 1
        total = len(self.waypoints)

        if distance <= self.tolerance_m:
            self.get_logger().info(f'========== WAYPOINT {number} REACHED ==========')
            self.active_index += 1
            self.publish_markers()
            if self.active_index == len(self.waypoints):
                self.get_logger().info('========== ROUTE COMPLETE ==========')
            else:
                self.get_logger().info(f'Next: waypoint {self.active_index + 1}')
            return

        angle_error = wrap_angle(math.atan2(dy, dx) - self.yaw)
        degrees = math.degrees(abs(angle_error))
        if degrees <= 15.0:
            direction = 'ahead'
        elif angle_error > 0:
            direction = f'{degrees:.0f} deg LEFT'
        else:
            direction = f'{degrees:.0f} deg RIGHT'
        self.get_logger().info(
            f'Waypoint {number}/{total} | {distance:.2f} m remaining | {direction}'
        )

    def publish_markers(self):
        stamps = self.get_clock().now().to_msg()
        clear = Marker()
        clear.header.frame_id = 'map'
        clear.header.stamp = stamps
        clear.action = Marker.DELETEALL
        markers = [clear]
        for i, (x, y) in enumerate(self.waypoints):
            marker = Marker()
            marker.header.frame_id = 'map'
            marker.header.stamp = stamps
            marker.ns = 'manual_waypoints'
            marker.id = i
            marker.type = Marker.SPHERE
            marker.action = Marker.ADD
            marker.pose.position.x = x
            marker.pose.position.y = y
            marker.pose.position.z = 0.1
            marker.pose.orientation.w = 1.0
            marker.scale.x = 0.20
            marker.scale.y = 0.20
            marker.scale.z = 0.20
            marker.color.a = 1.0
            if i < self.active_index:  # Reached = green
                marker.color.g = 1.0
            elif i == self.active_index:  # Active = yellow
                marker.color.r = 1.0
                marker.color.g = 0.85
            else:  # Queued = blue
                marker.color.b = 1.0
            markers.append(marker)
        self.marker_pub.publish(MarkerArray(markers=markers))

    def save_route(self, _request, response):
        if not self.waypoints:
            response.success = False
            response.message = 'There are no waypoints to save.'
            return response
        try:
            self.route_file.parent.mkdir(parents=True, exist_ok=True)
            data = {
                'frame_id': 'map',
                'waypoints': [{'x': x, 'y': y} for x, y in self.waypoints],
            }
            tmp = self.route_file.with_suffix(self.route_file.suffix + '.tmp')
            tmp.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
            os.replace(tmp, self.route_file)
            response.success = True
            response.message = f'Saved {len(self.waypoints)} waypoints to {self.route_file}'
        except (OSError, ValueError) as exc:
            response.success = False
            response.message = f'Could not save route: {exc}'
        return response

    def load_route(self, _request, response):
        try:
            data = json.loads(self.route_file.read_text(encoding='utf-8'))
            if data.get('frame_id') != 'map':
                raise ValueError('Saved route must use map frame')
            points = [(float(pt['x']), float(pt['y'])) for pt in data['waypoints']]
            if not points or not all(math.isfinite(v) for p in points for v in p):
                raise ValueError('Route must contain finite waypoint coordinates')
            self.waypoints = points
            self.active_index = 0
            self.publish_markers()
            response.success = True
            response.message = f'Loaded {len(points)} waypoints from {self.route_file}'
        except (OSError, ValueError, TypeError, KeyError) as exc:
            response.success = False
            response.message = f'Could not load route: {exc}'
        return response

    def clear_route(self, _request, response):
        self.waypoints = []
        self.active_index = 0
        self.publish_markers()
        response.success = True
        response.message = 'Current route cleared (saved file, if any, unchanged).'
        return response


def main(args=None):
    rclpy.init(args=args)
    node = ManualRouteMonitor()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
